﻿
Imports Clases

Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim empleado1 As Empleado = New Empleado()
        empleado1.Nombres = TextBox1.Text
        empleado1.Apellidos = TextBox3.Text
        empleado1.Documento = TextBox2.Text
        empleado1.Tipo = ComboBox1.Text
        empleado1.TipoContrato = ComboBox2.Text
        empleado1.calcularSueldo(3000)
        DataGridView1.Rows.Insert(0, empleado1.Tipo,
                                     empleado1.Nombres,
                                     empleado1.Apellidos,
                                     empleado1.Documento,
                                     empleado1.Sueldo)

    End Sub
End Class