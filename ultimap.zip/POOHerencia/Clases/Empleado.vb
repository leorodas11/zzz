﻿Public Class Empleado
    'Herencia'
    Inherits Persona
    'Atributos'
    Private _tipoContrato As String
    Private _sueldo As Double

    'Propiedades'
    Public Property TipoContrato As String
        Get
            Return _tipoContrato
        End Get
        Set(value As String)
            _tipoContrato = value
        End Set
    End Property
    Public Property Sueldo As Double
        Get
            Return _sueldo
        End Get
        Set(value As Double)
            _sueldo = value
        End Set
    End Property

    'Operacion/metodo'
    Public Sub calcularSueldo(sueldoBase As Double)
        If (Me.TipoContrato = "Contratado") Then
            Me.Sueldo = sueldoBase + 250
        ElseIf (Me.TipoContrato = "Nombrado") Then
            Me.Sueldo = sueldoBase + 500
        Else
            Me.Sueldo = 0
        End If
    End Sub
End Class
